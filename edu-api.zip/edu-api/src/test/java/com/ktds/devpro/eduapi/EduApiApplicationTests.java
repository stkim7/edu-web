package com.ktds.devpro.eduapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EduApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
