package com.ktds.devpro.eduapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EduApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(EduApiApplication.class, args);
	}

}
